#!/bin/bash

# =========================================================
# backup_full.sh - Script de backup comprimido con tar.gz
# =========================================================

show_help() {
    echo ""
    echo "Uso: backup_full.sh -origen <dir_origen> -destino <dir_destino>"
    echo ""
    echo "Opciones:"
    echo "  -origen   <ruta>   Directorio a respaldar"
    echo "  -destino  <ruta>   Directorio donde se guardara el backup"
    echo "  -help              Muestra esta ayuda"
    echo ""
    echo "Ejemplo:"
    echo "  backup_full.sh -origen /var/log -destino /backup_dir"
    echo ""
    echo "El archivo generado tendra el formato: <basename>_bkp_YYYYMMDD.tar.gz"
    echo "Ejemplo de salida: log_bkp_20240302.tar.gz"
    echo ""
    exit 0
}

if [[ $# -eq 0 ]]; then
    show_help
fi

ORIGEN=""
DESTINO=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        -origen)
            ORIGEN="$2"
            shift 2
            ;;
        -destino)
            DESTINO="$2"
            shift 2
            ;;
        -help|--help|-h)
            show_help
            ;;
        *)
            echo "ERROR: Argumento desconocido: $1"
            echo "Use -help para ver el uso correcto."
            exit 1
            ;;
    esac
done

if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "ERROR: Debe especificar -origen y -destino."
    echo "Use -help para ver el uso correcto."
    exit 1
fi

# Validar sistema de archivos de ORIGEN
if [[ ! -d "$ORIGEN" ]]; then
    echo "ERROR: El directorio de origen '$ORIGEN' no existe o no esta disponible."
    exit 1
fi

if [[ ! -r "$ORIGEN" ]]; then
    echo "ERROR: El origen '$ORIGEN' no tiene permisos de lectura."
    exit 1
fi

# Validar sistema de archivos de DESTINO
if [[ ! -d "$DESTINO" ]]; then
    echo "ERROR: El directorio de destino '$DESTINO' no existe o no esta montado."
    exit 1
fi

if [[ ! -w "$DESTINO" ]]; then
    echo "ERROR: El destino '$DESTINO' no tiene permisos de escritura."
    exit 1
fi

# Generar nombre del backup con formato: basename_bkp_YYYYMMDD.tar.gz
FECHA=$(date +%Y%m%d)
BASENAME=$(basename "$ORIGEN")
ARCHIVO="${BASENAME}_bkp_${FECHA}.tar.gz"
DESTINO_FINAL="${DESTINO}/${ARCHIVO}"

echo "========================================"
echo "  BACKUP FULL - $(date '+%Y-%m-%d %H:%M:%S')"
echo "========================================"
echo "  Origen  : $ORIGEN"
echo "  Destino : $DESTINO_FINAL"
echo "========================================"

tar -czf "$DESTINO_FINAL" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")" 2>&1

if [[ $? -eq 0 ]]; then
    TAMANO=$(du -sh "$DESTINO_FINAL" | cut -f1)
    echo "  Backup completado exitosamente."
    echo "  Archivo : $ARCHIVO"
    echo "  Tamano  : $TAMANO"
    echo "========================================"
    exit 0
else
    echo "ERROR: El backup fallo. Verifique los logs."
    exit 1
fi
